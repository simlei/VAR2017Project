# This is the archived project pitch from end of April 2017
# Presentation

Since the big project presentations are tomorrow, [here is mine :)](https://sway.com/LJc2ziR6jpuGUxak?ref=Link)

See you all :)

<iframe width="760px" height="500px" src="https://sway.com/s/LJc2ziR6jpuGUxak/embed" frameborder="0" marginwidth="0" marginheight="0" scrolling="no" style="border: none; max-width:100%; max-height:100vh" allowfullscreen webkitallowfullscreen mozallowfullscreen msallowfullscreen> </iframe>
